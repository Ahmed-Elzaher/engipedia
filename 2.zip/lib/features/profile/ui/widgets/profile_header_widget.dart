import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../core/utils/app_styles.dart';
import '../../../../core/widgets/scale_clickable.dart';

class ProfileHeaderWidget extends StatelessWidget {
  const ProfileHeaderWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24.r),
        boxShadow: const [
          BoxShadow(color: Color(0x40000000), offset: Offset(0, 25), blurRadius: 50, spreadRadius: -12),
          BoxShadow(color: Color(0x121F2687), offset: Offset(0, 8), blurRadius: 32),
          BoxShadow(color: Color(0x40000000), offset: Offset(0, 4), blurRadius: 4),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24.r),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24.r),
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFFFFFFF), Color(0xFFD6DAF5)],
              ),
            ),
            padding: const EdgeInsets.all(1.5),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 24.h),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22.5.r),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    const Color(0xFFFAFAFA).withOpacity(0.8),
                    const Color(0xFFD6DAF5).withOpacity(0.8)
                  ],
                ),
              ),
              child: Column(
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // 1. الصورة (ثابتة الحجم)
                      Stack(
                        children: [
                          Container(
                            width: 60.w,
                            height: 60.w,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: const Color(0xFFEAEDFA), width: 3),
                              image: const DecorationImage(
                                image: AssetImage('assets/images/pfp.png'),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          Positioned(
                            right: 0,
                            bottom: 0,
                            child: Container(
                              width: 16.w,
                              height: 16.w,
                              decoration: BoxDecoration(
                                color: const Color(0xFF22C55E),
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.white, width: 3),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(width: 16.w),
                      
                      // 2. 💡 البيانات (مغلفة بـ Expanded لمنع الأوفر فلو يميناً)
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Zeyad Khaled Mohamed",
                              style: AppStyles.h4Bold20.copyWith(color: const Color(0xFF0A0E29), fontSize: 18.sp),
                              overflow: TextOverflow.ellipsis, // لو الاسم طويل جداً
                            ),
                            SizedBox(height: 4.h),
                            Text(
                              "CCE Student",
                              style: AppStyles.pMedium16.copyWith(color: const Color(0xFF141C52)),
                            ),
                            SizedBox(height: 12.h),
                            Text(
                              "Passionate about Computer Engineering and Hardware Design.",
                              style: TextStyle(
                                fontFamily: 'Montserrat',
                                fontStyle: FontStyle.italic,
                                fontSize: 13.sp,
                                color: const Color(0xFF141C52),
                              ),
                            ),
                            SizedBox(height: 12.h),
                            
                            // 3. 💡 الروابط (استخدام Wrap بدل Row لمنع الأوفر فلو يميناً)
                            Wrap(
                              spacing: 12.w, // مسافة أفقية
                              runSpacing: 8.h, // مسافة لو نزل سطر جديد
                              children: [
                                _buildInfoItem(Icons.location_on_outlined, "CAIRO, EGYPT"),
                                _buildInfoItem(Icons.link_rounded, "ENGIPEDIA.IO/ZEYAD"),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 24.h),
                  
                  // زرار Edit Profile
                  ScaleClickable(
                    onTap: () {},
                    child: Container(
                      height: 44.h,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Color(0xFF1E2A7B), Color(0xFF0A0E29)],
                        ),
                        borderRadius: BorderRadius.circular(12.r),
                      ),
                      child: Center(
                        child: Text(
                          "Edit Profile",
                          style: TextStyle(
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.w500,
                            fontSize: 16.sp,
                            color: const Color(0xFFEAEDFA),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ويدجت مساعدة لبناء اللوكيشن واللينك بشكل مرن
  Widget _buildInfoItem(IconData icon, String text) {
    return Row(
      mainAxisSize: MainAxisSize.min, // بياخد مساحة النص بس
      children: [
        Icon(icon, size: 14.sp, color: const Color(0xFF0A0E29)),
        SizedBox(width: 4.w),
        Flexible( // بيخلي النص ينكمش أو يقطع لو المساحة ضيقة
          child: Text(
            text,
            style: TextStyle(
              fontFamily: 'Space Grotesk',
              fontWeight: FontWeight.w700,
              fontSize: 10.sp,
              letterSpacing: 0.6,
              color: const Color(0xFF141C52),
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}